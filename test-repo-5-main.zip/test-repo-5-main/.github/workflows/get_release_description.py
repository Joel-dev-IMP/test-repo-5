with open("../release_description.txt", "w+") as f:
    f.write(f"""Demo Addon Release""")
